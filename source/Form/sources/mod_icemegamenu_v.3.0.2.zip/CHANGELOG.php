<?php
/**
 * IceMegaMenu Extension for Joomla 3.0 By IceTheme
 * 
 * 
 * @copyright	Copyright (C) 2008 - 2013 IceTheme.com. All rights reserved.
 * @license		GNU General Public License version 2
 * 
 * @Website 	http://www.icetheme.com/Joomla-Extensions/icemegamenu.html
 *
 */
 
/* no direct access*/
defined('_JEXEC') or die;
/* Include the syndicate functions only once*/

?>

Copyright and disclaimer
---------------------------
This application is opensource software released under the GPL.  Please
see source code and the LICENSE file.


Changelog
------------

-------------------- 3.0.2 Stable Release [09-JANUARY-2013] ----------------
- some minor CSS adjustments
- solved ipad issue on responsive for "default" and "clean" themes.


-------------------- 3.0.1 Stable Release [29-APRIL-2012] ------------------
- fixed dropdown issue when there is no space on the right,
then appear on the left

- fixed modules inside the dropdown in responsive mode.

- added "clean" theme



-------------------- 3.0.0 Stable Release [10-NOVEMBER-2012] ------------------

